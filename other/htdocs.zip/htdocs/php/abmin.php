<?php
echo "The php<br>————————————————————<br>";
echo "？？？？？？";
?>