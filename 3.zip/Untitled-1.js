function dn(){
    resultTxt.innerHTML = '1234567899';
}
