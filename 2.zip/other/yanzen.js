function yanzen()
{
    window.alert(12345)
    window.alert(qeggg)
}